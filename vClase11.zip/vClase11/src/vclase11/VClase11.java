/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vclase11;

import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class VClase11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
          /* ----------------Ejercicio 1)------------------
        Solicitar al usuario que ingrese 3 números.
        Luego informar:
        La suma de los dos primeros
        La resta de los dos segundos
        El resto entre el primer número y el segundo
        La suma total
        El promedio
        
        Desarrollo:
        */ 
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Favor de ingresar tres números al azar. ");
        System.out.println("Ingrese el primero y pesione enter: ");
//               
//        
//        cuchame, el codigo funciona bien al poner valores como pi, phi y euler ;)        
//        
            
        
        double numero1 = teclado.nextDouble();
        double numero2 = teclado.nextDouble();
        double numero3 = teclado.nextDouble();
        
        double suma = numero1 + numero2;
        double restA = numero1 - numero2;
        double restO = numero1 % numero2;
        double sumatotal = numero1 + numero2 + numero3;
        double promedio = sumatotal / 3;
        
        System.out.println("La suma de los primeros números es: " + suma);
        
        System.out.println("La resta de los dos segundos números es: " + restA);
        
        System.out.println("El resto entre el primero y el segundo número es: " + restO);
        
        System.out.println("La suma del total es: " + sumatotal);
        
        System.out.println("El promedio es: " + promedio);
        
        
        /* -----------------Ejercicio 2)-------------------
        Solicitar al usario que ingrese dos números.
        Devolver el primer número aumentado en 17
        y el segundo número decrementado en 10
        
        Desarrollo:
        */
        
       
        System.out.println("Favor de ingresar dos numeros al azar. ");
        System.out.println("Ingrese el primero y pesione enter: ");
          
        double num1 = teclado.nextDouble();
        double num2 = teclado.nextDouble();
        
        double suma17 = num1 + 17;
        double restA10 = num2 - 10;
        
        System.out.println("El primer numero ingresado + 17 es igual a: " + suma17 );
        System.out.println("El segundo numero ingresado - 10 es igual a: " + restA10 ); 
        
        /*
        Otras maneras posibles: (estas maneras son preferibles para evitar gastar memoria)
        (estas siempre despues del nextdouble / nextint)
        (tambien reutilizamos variables para ahorrar memoria)
        
        int numero1 += 17;
        int numero2 -= 10;
        
        o tambien:
        
        int incremento = numero1 + 17;
        int decremento = numero - 10;
        
        */
                

/*-----------------Ejercicio 3)---------------------
        Solicitar al usuario que ingrese la base y la altura de un rectangulo e informar:
        El area del rectangulo
        El perimetro del rectangulo.
        
        Desarrollo:
        */
        
        System.out.println("Indicar la base del rectangulo en cm y presione enter.");
        System.out.println("Despues, ingrese la altura del rectangulo y presione enter.");
        
        double baseRect = teclado.nextDouble();
        double alturaRect = teclado.nextDouble();
        
        double area = baseRect * alturaRect;
        double perimetro = baseRect + alturaRect * 2;
        
        // para el perimetro tambien pude haber puesto: (base + altura) * 2;
        // aca la jerarquia de operaciones matematicas se escribe / interpreta igual que en la matematica com�n,
        //no hay error de sintaxis en este ejemplo
        
        System.out.println("El area del rectangulo es: " + area);
        System.out.println("El perimetro de rectangulo es: " + perimetro);
        

/* ---------------Ejercicio 4)----------------------
        Solicitar al usuario que ingrese el radio de un circulo en informar el area
        
        Desarrollo:
        */
        
        System.out.println("Para saber el area de un circulo, ingrese el radio del circulo en cuestion y luego presione enter");
        
        double radioCirculo = teclado.nextDouble();
        double radioElevado2 = radioCirculo * radioCirculo;
        double areaCirculo = radioElevado2 * 3.14159265358;
        
        System.out.println("El area del circulo es: " + areaCirculo);
        
         /* ---------------Ejercicio 5)--------------------
        Se pide que ingrese por consola dos párrafos y muestre por pantalla lo siguiente:
        1. Los párrafos, ¿son iguales con el operador relacional ==?
        2. Los párrafos, ¿poseen el mismo contenido? Sin importar si están en mayúsculas o
        minúsculas.
        3. Mostrar los párrafos en mayúsculas.
        4. Mostrar los párrafos en minúsculas.
        5. Mostrar la primera letra en mayúscula de cada párrafo.
        6. Unir los párrafos con una coma.
        
        Desarrollo:
        */
         
        
        
         
        /* -----------------Ejercicio 6)--------------------
        
        Crear un programa que solicite al usuario que ingrese su primer nombre y su apellido
        luego mostrarlo por consola, por separado, indicando cuál es su apellido primero y 
        luego debajo entre comillas dobles, su nombre
        Nombre y apellido deben ir con la primer letra en mayúscula
        
        Desarrollo:
        */
        
        
        
        
        
        
    }
    
}
